# Infinite Tic-Tac-Toe

An adaptive twist on classic Tic-Tac-Toe with persistent scoring, AI opponent, and dynamic visual effects.

## How It Works
- **Infinite Gameplay**: Players maintain only 3 pieces on board - new placements remove oldest pieces
- **Win Conditions**: Standard 3-in-a-row, checked *after* piece removal
- **Turn System**: Alternates between Player (X) and AI (O) with starting player switching after each game
- **Visual Feedback**: 
  - Preview ghost piece follows mouse (player) 
  - AI shows 3 fake moves before committing
  - Win lines animate across winning pattern
  - Score persistence between games
- **Accessibility**: High contrast colors with non-color dependent indicators

## File Structure
├── index.html # Main document structure + score display
├── styles.css # All visual styling + animations
├── game.js # Game logic/state management + AI

## Implemented Features
### Core Gameplay
- Infinite piece management (add/remove oldest)
- Win/draw detection
- Score persistence
- Alternating starting players
- Responsive AI with move previews

### Visual System
- Dynamic hover preview with:
  - Grid snapping
  - Distance-based opacity
  - Smooth interpolation (LERP)
- Win line animations:
  - Proper angle/length calculation
  - Auto-removal after animation
  - Color-matched to winner
- AI move preview effect
- Dark mode base
- Orbritron font usage
- Piece impact animations

### Technical Foundation
- Pure web stack (no dependencies)
- Class-based game architecture
- Position-aware effect system
- State management for easy extension

## Future Improvements
1. **Visual Effects**
   - Confetti burst (player win)
   - Animated robot mascot (AI win)
   - Piece fade-out animation
   - Sound effects

2. **Gameplay Enhancements**
   - Smart AI (currently random moves)
   - Move history system
   - Save/load state

3. **Accessibility**
   - Full keyboard controls
   - Screen reader support
   - Motion reduction toggle

4. **Polish**
   - Mobile optimization
   - Settings menu
   - Advanced statistics

## Important Notes
1. **Design Philosophy**
   - Prioritized visual feedback for state changes
   - Used CSS custom properties for easy theming
   - Maintained pure JS implementation for transparency
   - Implemented defensive position calculations for grid elements

2. **Performance Choices**
   - RequestAnimationFrame for smooth animations
   - CSS transforms over layout-changing properties
   - Event delegation for grid interactions

3. **Architecture**
   - Game state encapsulated in `InfiniteTicTacToe` class
   - Visual effects layer separated from core logic
   - Position calculations relative to grid container
   - Async/await used for sequenced AI moves

4. **Accessibility Status**
   - Currently meets WCAG AA for contrast (4.65:1)
   - Needs ARIA labels for screen readers
   - Animation durations respect prefers-reduced-motion

**Reasoning**: Built as foundation-first with extension hooks - all core gameplay works with placeholder effects that can be enhanced without breaking core logic. The AI uses simple random moves to enable easier smart AI implementation later.


## Gameplay Specification (LLM Context)

**Core State Machine**
```yaml
GameState:
  cells: Array[9]<'X'|'O'|null>  # Current board state
  playerPieces: Array[index]      # Indices of player pieces (FIFO)
  aiPieces: Array[index]          # Indices of AI pieces (FIFO)
  currentPlayer: 'X'|'O'          # Active turn
  scores: {player: int, ai: int}  # Persistent scores
  gameActive: bool                # Win/draw state
  startingPlayer: 'X'|'O'         # Alternates post-game
```

**Turn Flow**
1. Player Turn (X):
   - Mouse input → grid index
   - Add to playerPieces (enforce max 3 via FIFO removal)
   - Check win/draw conditions
   - If game continues → trigger AI turn

2. AI Turn (O):
   - Generate empty cell indices
   - Animate 3 random previews (300ms intervals)
   - Select random valid index
   - Add to aiPieces (FIFO enforcement)
   - Check win conditions

**Piece Management**
- Add: Append index to player/aiPieces
- Remove: Shift oldest piece when length > 3
- Critical Order:
  1. Remove overflow piece (if needed)
  2. Update cells array
  3. Check win condition
  4. Update DOM

**Win Detection**
- Pattern matching against current pieces array
- Win patterns: 8 possible lines (3 rows, 3 cols, 2 diags)
- Draw: All cells filled without win
- On win:
  - Animate line from first→last pattern cell
  - Update scores
  - Reset board after 2000ms

**AI System**
- Move selection: Uniform random from empty cells
- Preview mechanic:
  - 3 transient highlights (non-destructive)
  - Final selection persists
- Async flow using setTimeout/await

**Visual Systems**
1. Hover Effect:
   - Grid-relative position calculation
   - Lerp: currentPos + (targetPos - currentPos) * 0.2
   - Snap threshold: ±25px from cell center
   - Opacity: 0.4 → 0 over 100px exit distance

2. Impact Animation:
   - CSS scale(0)→scale(1.1)→scale(1)
   - Cubic bezier timing (overshoot effect)

3. DOM Sync:
   - Cell classes updated after state changes
   - Effects container managed separately from grid

**Event Pipeline**
1. Input → State Change → DOM Update → Visual Feedback
2. Position calculations use getBoundingClientRect()
3. All animations relative to grid container position

**Key Implementation Details**
- Timeout IDs not tracked (assumes single instance)
- CSS Variables drive theming
- Class-based state encapsulation
- No framework dependencies
- RAF not used (setTimeout OK for this complexity)

**Edge Case Considerations**
- Multiple quick clicks → ignored via gameActive flag
- Window resize → natural reposition via relative units
- Piece removal timing → guaranteed pre-win check
- Draw state precedence → checked after win verification

This formalization enables precise game simulation and AI training. The implementation prioritizes observable fidelity over theoretical optimization, with explicit state transitions that match visual feedback timing.