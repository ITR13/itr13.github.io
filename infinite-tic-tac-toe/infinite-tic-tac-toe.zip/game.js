// game.js
class InfiniteTicTacToe {
    constructor() {
        this.cells = Array(9).fill(null);
        this.playerPieces = [];
        this.aiPieces = [];
        this.currentPlayer = 'X';
        this.startingPlayer = 'X';
        this.scores = { player: 0, ai: 0 };
        this.gameActive = true;
        this.gridContainer = document.getElementById('grid-container');
        this.previewPiece = this.createPreviewPiece();
        this.gridContainer.addEventListener('mousemove', this.handleMouseMove.bind(this));
        this.initGrid();
    }

    createPreviewPiece() {
        const preview = document.createElement('div');
        preview.style.position = 'absolute';
        preview.style.pointerEvents = 'none';
        preview.style.opacity = '0';
        preview.classList.add('preview');
        document.getElementById('effects-container').appendChild(preview);
        return preview;
    }

    initGrid() {
        this.gridContainer.innerHTML = '';
        for (let i = 0; i < 9; i++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.dataset.index = i;
            cell.addEventListener('click', () => this.handleClick(i));
            this.gridContainer.appendChild(cell);
        }
    }

    handleMouseMove(e) {
        if (!this.gameActive || this.currentPlayer !== 'X') {
            this.previewPiece.style.opacity = '0';
            return;
        }


        const gridRect = this.gridContainer.getBoundingClientRect();
        const effectsRect = document.getElementById('effects-container').getBoundingClientRect();

        // Convert mouse position to grid-relative coordinates
        const x = e.clientX - effectsRect.left;
        const y = e.clientY - effectsRect.top;

        const cellSize = gridRect.width / 3;

        // Calculate position relative to grid
        let targetX = x;
        let targetY = y;

        // Snap to grid logic
        const col = Math.floor(x / cellSize);
        const row = Math.floor(y / cellSize);

        if (col >= 0 && col < 3 && row >= 0 && row < 3) {
            // Snap to cell center
            targetX = col * cellSize + cellSize / 2;
            targetY = row * cellSize + cellSize / 2;
        } else {
            // Follow mouse with distance-based opacity
            const distToGrid = Math.max(
                gridRect.left - e.clientX,
                e.clientX - gridRect.right,
                gridRect.top - e.clientY,
                e.clientY - gridRect.bottom
            );
            const opacity = Math.max(0, 0.4 - distToGrid * 0.002);
            this.previewPiece.style.opacity = opacity;
        }

        // Smooth movement with lerp
        const currentX = parseFloat(this.previewPiece.style.left) || targetX;
        const currentY = parseFloat(this.previewPiece.style.top) || targetY;

        this.previewPiece.textContent = this.currentPlayer;
        this.previewPiece.style.color = this.currentPlayer === 'X' ? 'var(--blue-x)' : 'var(--red-o)';
        this.previewPiece.style.left = `${currentX + (targetX - currentX) * 0.2}px`;
        this.previewPiece.style.top = `${currentY + (targetY - currentY) * 0.2}px`;
    }

    handleClick(index) {
        if (!this.gameActive || this.currentPlayer !== 'X') return;
        if (this.cells[index]) return;

        this.placePiece(index, 'X');
        this.checkGameState();

        if (this.gameActive) {
            this.currentPlayer = 'O';
            setTimeout(() => this.aiMove(), 1000);
        }
    }

    placePiece(index, player) {
        this.cells[index] = player;
        const pieces = player === 'X' ? this.playerPieces : this.aiPieces;
        pieces.push(index);

        if (pieces.length > 3) {
            const removed = pieces.shift();
            this.cells[removed] = null;
            this.updateCell(removed);
        }

        this.updateCell(index);
    }

    updateCell(index) {
        const cell = this.gridContainer.children[index];
        cell.className = `cell ${this.cells[index] ? this.cells[index].toLowerCase() : ''}`;
    }

    checkGameState() {
        if (this.checkWin('X')) {
            this.handleWin('player');
        } else if (this.checkWin('O')) {
            this.handleWin('ai');
        } else if (this.cells.every(cell => cell)) {
            this.handleDraw();
        }
    }

    checkWin(player) {
        const pieces = player === 'X' ? this.playerPieces : this.aiPieces;
        const winPatterns = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6] // Diagonals
        ];

        return winPatterns.some(pattern =>
            pattern.every(index => pieces.includes(index))
        );
    }

    handleWin(winner) {
        this.gameActive = false;
        this.startingPlayer = winner === 'player' ? 'O' : 'X';

        this.drawWinLine(winner);

        if (winner === 'player') {
            this.scores.player++;
            // Add confetti effect
        } else {
            this.scores.ai++;
            // Add robot effect
        }

        setTimeout(() => {
            this.resetGame();
            this.currentPlayer = this.startingPlayer;
        }, 2000);
    }

    handleDraw() {
        this.gameActive = false;
        this.startingPlayer = this.startingPlayer === 'X' ? 'O' : 'X';
        setTimeout(() => {
            this.resetGame();
            this.currentPlayer = this.startingPlayer;
        }, 1000);
    }

    drawWinLine(winner) {
        const winPattern = this.getWinningPattern(winner === 'player' ? 'X' : 'O');
        if (!winPattern) return;

        const line = document.createElement('div');
        line.classList.add('win-line', winner === 'player' ? 'x' : 'o');
        document.getElementById('effects-container').appendChild(line);

        const [a, b, c] = winPattern;
        const gridRect = this.gridContainer.getBoundingClientRect();
        const cell1Rect = this.gridContainer.children[a].getBoundingClientRect();
        const cell3Rect = this.gridContainer.children[c].getBoundingClientRect();

        // Calculate positions relative to grid
        const startX = cell1Rect.left - gridRect.left + cell1Rect.width / 2;
        const startY = cell1Rect.top - gridRect.top + cell1Rect.height / 2;
        const endX = cell3Rect.left - gridRect.left + cell3Rect.width / 2;
        const endY = cell3Rect.top - gridRect.top + cell3Rect.height / 2;

        const angle = Math.atan2(endY - startY, endX - startX);
        const length = Math.hypot(endX - startX, endY - startY);

        Object.assign(line.style, {
            width: `${length}px`,
            left: `${startX}px`,
            top: `${startY}px`,
            transform: `rotate(${angle}rad)`,
        });

        // Remove line after animation
        setTimeout(() => line.remove(), 1000);
    }

    getWinningPattern(player) {
        const pieces = player === 'X' ? this.playerPieces : this.aiPieces;
        const winPatterns = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6] // Diagonals
        ];

        return winPatterns.find(pattern =>
            pattern.every(index => pieces.includes(index))
        );
    }

    resetGame() {
        this.cells = Array(9).fill(null);
        this.playerPieces = [];
        this.aiPieces = [];
        this.gameActive = true;
        this.currentPlayer = this.startingPlayer;
        this.initGrid();
        this.updateScores();
    }

    async aiMove() {
        const emptyCells = this.cells
            .map((cell, index) => cell ? null : index)
            .filter(index => index !== null);

        // Preview 3 random cells
        const previews = [];
        for (let i = 0; i < 3; i++) {
            const previewIndex = emptyCells[Math.floor(Math.random() * emptyCells.length)];
            previews.push(previewIndex);
            this.showPreview(previewIndex);
            await new Promise(resolve => setTimeout(resolve, 300));
            this.hidePreview(previewIndex);
        }

        // Choose actual move (ensure it's different from previews if possible)
        const chosenIndex = emptyCells[Math.floor(Math.random() * emptyCells.length)];
        this.showPreview(chosenIndex);
        await new Promise(resolve => setTimeout(resolve, 200));
        this.hidePreview(chosenIndex);

        this.placePiece(chosenIndex, 'O');
        this.checkGameState();
        this.currentPlayer = 'X';
    }

    showPreview(index) {
        const cell = this.gridContainer.children[index];
        const preview = document.createElement('div');
        preview.className = 'ai-preview o';
        preview.style.animation = 'aiPreview 0.3s forwards';
        cell.appendChild(preview);
    }

    hidePreview(index) {
        const cell = this.gridContainer.children[index];
        const preview = cell.querySelector('.ai-preview');
        if (preview) {
            preview.style.animation = 'aiPreviewOut 0.2s forwards';
            setTimeout(() => preview.remove(), 200);
        }
    }

    // This was redefined, but I don't think that's correct?
    /*
    showPreview(index) {
        const cell = this.gridContainer.children[index];
        cell.classList.add('preview-o');
    }
 
    hidePreview(index) {
        const cell = this.gridContainer.children[index];
        cell.classList.remove('preview-o');
    }
    */

    updateScores() {
        document.getElementById('player-score').textContent = this.scores.player;
        document.getElementById('ai-score').textContent = this.scores.ai;
        const turnText = this.currentPlayer === 'X' ? 'PLAYER' : 'AI';
        document.getElementById('turn-indicator').textContent = `${turnText}'S TURN`;
    }
}

// Initialize the game
const game = new InfiniteTicTacToe();